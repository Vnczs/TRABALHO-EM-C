#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-59 - O Assistente de Dire��o (GPS Sem Mapa) ");
printf("\n************************************************************************************************************************");
char direcao;

    printf("--- SISTEMA DE NAVEGACAO DO ROBO ---\n");
    printf("Digite a letra da placa (N, S, L, O): ");
    scanf(" %c", &direcao); 
    printf("\n[Robo]: ");
    switch (direcao) {
        case 'N':
        case 'n':
            printf("Seguir para o Norte.\n");
            break;
        case 'S':
        case 's':
            printf("Seguir para o Sul.\n");
            break;
        case 'L':
        case 'l':
            printf("Virar a Leste (Direita).\n");
            break;
        case 'O':
        case 'o':
            printf("Virar a Oeste (Esquerda).\n");
            break;
        default:
            printf("Comando invalido! Pare o robo.\n");
            break;
    }
system("pause");
}
