#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-33 - Multiplos de 3 entre 1 e 30 ");
printf("\n************************************************************************************************************************");
int i;
printf("Os numeros multiplos de 3 entre 1 e 30 sao:\n");
for(i=3; i<=30; i=i+3){
printf("%d\n",i);	
}



system("pause");

}
