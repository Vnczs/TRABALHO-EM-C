#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-54 - Validar n�mero entre 1 e 5 ");
printf("\n************************************************************************************************************************");
int nivel;

    printf("--- JOGO EDUCATIVO ---\n");
    do {
        printf("Escolha o nivel de dificuldade (entre 1 e 5): ");
        scanf("%d", &nivel);
        if (nivel < 1 || nivel > 5) {
            printf("[Erro] Nivel invalido! O numero precisa ser de 1 ate 5.\n\n");
        }

    } while (nivel < 1 || nivel > 5); 
    
    printf("\nNivel %d selecionado com sucesso! Carregando o jogo...\n", nivel);







system("pause");
}
