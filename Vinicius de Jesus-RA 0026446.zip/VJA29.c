#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-29 -  Numeros pares de 0 a 50");
printf("\n************************************************************************************************************************");
int i;
for(i=0; i<=50; i=i+2){
printf("Os numeros sao:%d\n", i);	
}



system("pause");



}
