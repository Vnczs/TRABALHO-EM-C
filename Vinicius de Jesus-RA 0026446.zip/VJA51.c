#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-51 - Contagem regressiva de 10 at 1 ");
printf("\n************************************************************************************************************************");
int contador = 10;

    printf("Preparar para a largada!...\n");

    
    do {
        printf("%d\n", contador);
        contador--;
    } while (contador >= 1);

    printf("CORRAM! ???????\n");



system("pause");
}
