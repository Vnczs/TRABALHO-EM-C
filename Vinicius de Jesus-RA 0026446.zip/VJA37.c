#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-36 - Contar ate 10 com while ");
printf("\n************************************************************************************************************************");
float soma;
float valor;
printf("Digite o valor do produto(ou zero para fechar):");
scanf("%f", &valor);
while(valor!=0){
	soma = soma + valor;
printf("digite o valor(ou zero para fechar):");
scanf("%f", &valor);

}
printf("O valor dos produtos e: R$ %.2f:", soma);
system("pause");
}
