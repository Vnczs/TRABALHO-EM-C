#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-40 - Tabuada com while ");
printf("\n************************************************************************************************************************");
int num;
int i;
int resultado;
printf("tabuada do:");
scanf("%d", &num);
i=1;
while(i<=10){
resultado = num * i;
printf("%d x %d = %d\n", num, i, resultado);
i++;
}
  



system("pause");
}
