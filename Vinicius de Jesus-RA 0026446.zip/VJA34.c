#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-34 - Verificar se um numero e primo ");
printf("\n************************************************************************************************************************");
int num;
int primo=1;
int i;
printf("digite um numero:");
scanf("%d", &num);
for(i=2; i<num;i++){
	if(num % i == 0){
		primo = 0;
	}

	}
if(primo ==1){
	printf("e primo\n");	
}else{
	printf("nao e primo\n");
}

system("pause");
}







