#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-41 - Numero primo com while");
printf("\n************************************************************************************************************************");
int numero;
int i = 1;         
int divisores = 0;  
printf("Digite um numero inteiro positivo: ");
scanf("%d", &numero);
while (i <= numero) {
if (numero % i == 0) {
divisores++; 
}
i++; 
}
if (divisores == 2) {
printf("O numero %d e PRIMO.\n", numero);
} else {
printf("O numero %d NAO e PRIMO.\n", numero);
}

system("pause");




}
