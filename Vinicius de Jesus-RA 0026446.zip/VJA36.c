#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-36 - Contar ate 10 com while ");
printf("\n************************************************************************************************************************");
int contador=1;
while(contador<=10){	
printf("%d\n", contador);
contador++;
}











}
