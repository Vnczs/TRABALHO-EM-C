#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-55 -Ler numeros e mostrar o maior (ate digitar negativo)");
printf("\n************************************************************************************************************************");
float nota;
    float maiorNota;
    int primeiraNota = 1; 

    printf("--- PESQUISA ESCOLAR: REGISTRO DE NOTAS ---\n");
    printf("Digite as notas dos participantes. Digite uma nota negativa para encerrar.\n\n");

    do {
        printf("Informe a nota: ");
        scanf("%f", &nota);
        if (nota >= 0) {
            
            if (primeiraNota == 1) {
                maiorNota = nota;
                primeiraNota = 0; 
            } 
            
            else if (nota > maiorNota) {
                maiorNota = nota;
            }
        }

    } while (nota >= 0); 

    printf("\n--- RESULTADO DA PESQUISA ---\n");
    
    if (primeiraNota == 0) {
        printf("A maior nota positiva informada foi: %.2f\n", maiorNota);
    } else {
        printf("Nenhuma nota valida foi registrada.\n");
    }













system("pause");
}
