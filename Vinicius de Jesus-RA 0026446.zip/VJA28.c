#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-28 - Soma dos 100 primeiros n�meros naturais");
printf("\n************************************************************************************************************************");
int i;
int soma=0;
for(i=1; i<=100; i++){
	soma= soma + i;	
}
printf("o resultado da soma e:%d\n", soma);



system("pause");





}
