#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-38 - Senha correta ");
printf("\n************************************************************************************************************************");
int senha = 9868;
int tentativa;
printf("Digite a sua senha:");
scanf("%d", &tentativa);
while(tentativa!=senha){
	printf("senha incorreta! Tente novamente.\n");
	printf("Digite a sua senha:");
	scanf("%d", &tentativa);
}
printf("acesso liberado!\n");



system("pause");



}
