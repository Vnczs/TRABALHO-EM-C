#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-16 - Multiplo de 3 e/ou 5 ");
printf("\n************************************************************************************************************************");
int pedido;
printf("Qual o numero do pedido?");
scanf("%d", &pedido);
if(pedido % 3 == 0 && pedido % 5 == 0){
printf("Voce ganhou refrigerante e sobremesa!");
}else if (pedido % 3 == 0){
printf("Voce ganhou refrigerante!");
}else if(pedido % 5 == 0){
printf("Voce ganhou sobremesa!");
}else{
printf("Nao ganhou brindes mas bom apetite!");
system("pause");
}
}
