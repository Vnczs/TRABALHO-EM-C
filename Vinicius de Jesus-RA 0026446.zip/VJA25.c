#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-25 - Notas e aprova��o");
printf("\n************************************************************************************************************************");
float nota1, nota2, media;
printf("digite a primeira nota:");
scanf("%f", &nota1);
printf("digite a segunda nota:");
scanf("%f", &nota2);
media = (nota1+nota2)/2;
printf("Sua media e: %.2f\n", media);
if (media >= 7){
printf("Voce esta aprovado\n!");
} else if(media >= 5){
printf("Voce esta de recuperacao\n!");
}else{
printf("Voce esta reprovado");
}
system("pause");
}









