#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-27 - Tabuada de um numero");
printf("\n************************************************************************************************************************");
int num, i;
printf("Digite um numero:");
scanf("%d", &num);
for(i=1;i<=10; i++){
printf("%d * %d = %d\n", num, i, num * i);
}
system("pause");





}
