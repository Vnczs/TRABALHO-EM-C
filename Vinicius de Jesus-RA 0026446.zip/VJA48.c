#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-48 - Menu com op��o de sair ");
printf("\n************************************************************************************************************************");
int opcao;

   
    do {
        printf("\n=== MENU DE OPCOES ===\n");
        printf("1 - Mensagem\n");
        printf("2 - Sair\n");
        printf("======================\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            printf("\nVoce escolheu a mensagem!\n");
        } 
        else if (opcao == 2) {
            printf("\nSaindo do programa...\n");
        } 
        else {
            printf("\nOpcao invalida! Tente novamente.\n");
        }

    } while (opcao != 2); 



system("pause");
}
