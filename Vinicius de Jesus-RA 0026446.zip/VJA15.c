#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-15 - Quantas caixas cabem dentro do caminhao");
printf("\n************************************************************************************************************************");
int total_caixas;
float comprimento, largura, altura;
float comp, larg, alt, vol_caminhao, vol_caixa;
printf("Qual o comprimento do caminhao?");
scanf("%f", &comprimento);
printf("Qual a largura do caminhao?");
scanf("%f", &largura);
printf("Qual a altura do caminhao?");
scanf("%f", &altura);
printf("Qual o comprimento da caixa?");
scanf("%f", &comp);
printf("Qual o largura da caixa?");
scanf("%f", &larg);
printf("Qual o altura da caixa?");
scanf("%f", &alt);
comprimento = comprimento * 100;
largura = largura * 100;
altura = altura * 100;
vol_caminhao = comprimento * largura * altura;
vol_caixa = comp * larg * alt;
total_caixas = vol_caminhao / vol_caixa;
printf("A quantidade de caixas e: %d\n", total_caixas);
system("pause");
}
