#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-14 - Tipo de Triangulo");
printf("\n************************************************************************************************************************");

float a,b,c;
printf("Escreva o valor do lado A:");
scanf("%f", &a);
printf("Escreva o valor do lado B:");
scanf("%f", &b);
printf("Escreva o valor do lado C:");
scanf("%f", &c);
if((a+b>c) && (a+c>b) && (b+c>a)){
}
if(a==b && b==c){
printf("O triangulo e equilatero\n");
}else if (a != b && b != c && a != c){
printf("O triangulo e escaleno\n");
}else{	
printf("O triangulo e isosceles");
}
system("pause");
}
