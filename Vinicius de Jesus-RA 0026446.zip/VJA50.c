#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-50 - Numero positivo obrigatorio ");
printf("\n************************************************************************************************************************");
float valor_deposito;

    printf("--- AREA DE DEPOSITOS ---\n\n");

    
    do {
        printf("Digite o valor que deseja depositar (deve ser maior que zero): R$ ");
        scanf("%f", &valor_deposito);

        
        if (valor_deposito <= 0) {
            printf("Erro: Valor invalido! O deposito deve ser um numero positivo.\n\n");
        }

    } while (valor_deposito <= 0); 

    
    printf("\nDeposito de R$ %.2f realizado com sucesso!\n", valor_deposito);


system("pause");
}
