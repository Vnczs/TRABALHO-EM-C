#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-47 - Tabuada de um n�mero ");
printf("\n************************************************************************************************************************");
int numero;
    int i = 1; 

    printf("--- Gerador de Tabuada ---\n\n");
    printf("Digite um numero para ver sua tabuada: ");
    scanf("%d", &numero);

    printf("\nTabuada do %d:\n", numero);

  
    do {
        int resultado = numero * i;
        printf("%d x %d = %d\n", numero, i, resultado);
        
        i++; 
        
    } while (i <= 10); 



system("pause");
}
