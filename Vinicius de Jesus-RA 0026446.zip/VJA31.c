#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-31 - Contagem regressiva.");
printf("\n************************************************************************************************************************");
int i;
for(i=10; i>=1;i--){
printf("%d\n", i);
}



system("pause");






}
