#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-58 - A Calculadora de Bolso de 4 Opera��es");
printf("\n************************************************************************************************************************");
float num1, num2, resultado;
    char operacao;
    printf("--- CALCULADORA DE BOLSO ---\n");
    printf("Digite o primeiro numero: ");
    scanf("%f", &num1);
    printf("Digite o segundo numero: ");
    scanf("%f", &num2);
    printf("Escolha a operacao (+, -, *, /): ");
    scanf(" %c", &operacao); 

    printf("\n--- RESULTADO ---\n");

    switch (operacao) {
        case '+':
            resultado = num1 + num2;
            printf("%.2f + %.2f = %.2f\n", num1, num2, resultado);
            break;

        case '-':
            resultado = num1 - num2;
            printf("%.2f - %.2f = %.2f\n", num1, num2, resultado);
            break;

        case '*':
            resultado = num1 * num2;
            printf("%.2f * %.2f = %.2f\n", num1, num2, resultado);
            break;

        case '/':
            
            if (num2 != 0) {
                resultado = num1 / num2;
                printf("%.2f / %.2f = %.2f\n", num1, num2, resultado);
            } else {
                printf("Erro: Nao e possivel dividir por zero!\n");
            }
            break;

        default:
            printf("Operacao matematica nao reconhecida.\n");
            break;
    }
system("pause");
}
