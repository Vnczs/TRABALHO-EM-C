#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-53 - Confirmar sa�da com 's' ");
printf("\n************************************************************************************************************************");
char opcao_sair;
    int escolha;
    do {
        printf("\n--- SISTEMA DE CADASTRO ---\n");
        printf("1 - Cadastrar Novo Usuario\n");
        printf("2 - Listar Usuarios\n");
        printf("3 - Excluir Cadastro\n");
        printf("---------------------------\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &escolha);
        switch(escolha) {
            case 1:
                printf("\n[Executando: Cadastro realizado com sucesso!]\n");
                break;
            case 2:
                printf("\n[Executando: Listando usuarios cadastrados...]\n");
                break;
            case 3:
                printf("\n[Executando: Cadastro excluido!]\n");
                break;
            default:
                printf("\n[Opcao invalida!]\n");
        }

        
        printf("\nDeseja sair do programa? (Digite 's' para sim, ou qualquer outra letra para continuar): ");
        scanf(" %c", &opcao_sair); 

    } while (opcao_sair != 's' && opcao_sair != 'S'); 

    printf("\nSistema encerrado. Ate logo!\n");




system("pause");
}
