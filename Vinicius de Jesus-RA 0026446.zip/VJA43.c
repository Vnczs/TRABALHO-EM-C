#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-43 - Soma dos pares entre 1 e 100");
printf("\n************************************************************************************************************************");
int i = 2;          
    int soma_pares = 0;
    while (i <= 100) {
        soma_pares = soma_pares + i; 
        
        i = i + 2; 
    }
    printf("A soma de todos os numeros pares entre 1 e 100 e: %d\n", soma_pares);




system("pause");





}
