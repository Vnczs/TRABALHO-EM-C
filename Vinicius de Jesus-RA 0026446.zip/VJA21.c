#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-21 - numero positivo ou negativo");
printf("\n************************************************************************************************************************");
float numero;
printf("Digite um numero: ");
scanf("%f", &numero);
if (numero > 0) {
printf("O numero e POSITIVO.\n");
} 
else if (numero < 0) {
printf("O numero e NEGATIVO.\n");
}
else {
printf("O numero e ZERO.\n");
}
system("pause");
    
}

