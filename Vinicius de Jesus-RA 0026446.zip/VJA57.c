#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-57 - A Central do Brinquedo Eletr�nico ");
printf("\n************************************************************************************************************************");
char cor;

    // Menu explicativo para o sistema do urso
    printf("--- CENTRAL DO BRINQUEDO ELETRONICO ---\n");
    printf("Digite a inicial da cor que acendeu na barriga do urso:\n");
    printf("[V] - Verde\n");
    printf("[A] - Amarelo\n");
    printf("[M] - Vermelho\n");
    printf("---------------------------------------\n");
    printf("Cor: ");
    scanf(" %c", &cor); 

    printf("\n[Urso de Pelucia]: ");

    
    switch (cor) {
        
        case 'v':
        case 'V':
            printf("\"Vamos brincar la fora!\"\n");
            break;

        case 'a':
        case 'A':
            printf("\"Estou ficando com soninho...\"\n");
            break;

        case 'm': 
        case 'M':
            printf("\"Estou com fome, hora do lanche!\"\n");
            break;

        default:
            printf("Cor desconhecida. *Pisca as luzes* ?\n");
            break;
    }
system("pause");
}
