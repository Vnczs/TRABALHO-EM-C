#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-52 - Soma at� o n�mero ser m�ltiplo de 10 ");
printf("\n************************************************************************************************************************");
int numero;
    int somaTotal = 0;

    printf("--- Sistema de Pontuacao ---\n");
    printf("Digite os numeros para somar. O programa encerra ao digitar um multiplo de 10.\n\n");

    do {
        printf("Digite um numero: ");
        scanf("%d", &numero);

        somaTotal += numero; 

    } while (numero % 10 != 0); 

    printf("\n--- Fim do Programa ---\n");
    printf("A soma total de todos os valores informados e: %d\n", somaTotal);




system("pause");
}
