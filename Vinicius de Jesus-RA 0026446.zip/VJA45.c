#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-45 - Menu ate escolher sair");
printf("\n************************************************************************************************************************");
int opcao = 0; 
    
    while (opcao != 3) {
        printf("\n=== CAIXA ELETRONICO ===\n");
        printf("1 - Verificar Saldo\n");
        printf("2 - Realizar Saque\n");
        printf("3 - Sair do Sistema\n");
        printf("========================\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);
        if (opcao == 1) {
            printf("\n[Saldo] Seu saldo atual e: R$ 1.500,00\n");
        } 
        else if (opcao == 2) {
            printf("\n[Saque] Digite o valor que deseja sacar...\n");
        } 
        else if (opcao == 3) {
            printf("\nSaindo do sistema... Obrigado por utilizar o nosso caixa!\n");
        } 
        else {
            printf("\nOpcao INVALIDA! Tente novamente.\n");
        }
    }
    system("pause");
}
