#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-39 - Verificar se um n�mero � positivo ");
printf("\n************************************************************************************************************************");
float valor;
printf("Digite um valor:");
scanf("%f", &valor);
while(valor<=0){
	printf("Erro! O valor nao pode ser negativo ou zero! Tente de novo!");
	scanf("%f", &valor);
}
printf("Valor aceito e cadastrado!");



system("pause");
}
