#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-30 - Fatorial de um numero");
printf("\n************************************************************************************************************************");
int i, num;
int fatorial=1;
printf("Digite um numero:");
scanf("%d", &num);
for(i=num; i>=1; i--){
fatorial=fatorial*i;
}
printf("Valor fatorial e:%d\n", fatorial);

system("pause");

}
