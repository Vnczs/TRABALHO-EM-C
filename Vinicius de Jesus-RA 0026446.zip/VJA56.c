#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-56 - O Menu do Fast-Food Digital ");
printf("\n************************************************************************************************************************");
int combo;
    printf("--- FAST-FOOD DIGITAL ---\n");
    printf("Escolha o seu combo:\n");
    printf("1 - Combo Hamburguer + Batata + Refri\n");
    printf("2 - Combo Pizza Brotinho + Refri\n");
    printf("3 - Combo Salada + Suco Natural\n");
    printf("4 - Combo Balde de Frango + Molho\n");
    printf("-------------------------\n");
    printf("Digite o numero do combo desejado: ");
    scanf("%d", &combo);
    printf("\n--- RESUMO DO PEDIDO ---\n");
    switch (combo) {
        case 1:
            printf("Combo Hamburguer + Batata + Refri - R$ 30,00\n");
            break;

        case 2:
            printf("Combo Pizza Brotinho + Refri - R$ 25,00\n");
            break;

        case 3:
            printf("Combo Salada + Suco Natural - R$ 22,00\n");
            break;

        case 4:
            printf("Combo Balde de Frango + Molho - R$ 35,00\n");
            break;

        default:
            printf("Opcao invalida! Escolha de 1 a 4.\n");
            break;
    }


    printf("------------------------\n");
system("pause");
}
