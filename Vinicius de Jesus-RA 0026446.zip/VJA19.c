#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-19 - Ordem crescente (tres numeros) ");
printf("\n************************************************************************************************************************");
float n1, n2, n3;
printf("Qual a primeira nota?");
scanf("%f", &n1);
printf("Qual a segunda nota?");
scanf("%f", &n2);
printf("Qual a terceira nota?");
scanf("%f", &n3);
if (n1 < n2 && n1 < n3) {
if (n2 < n3) {
printf("%.1f, %.1f, %.1f\n", n1, n2, n3);
} else {
printf("%.1f, %.1f, %.1f\n", n1, n3, n2);
}
} 
else if (n2 < n1 && n2 < n3) {
if (n1 < n3) {
printf("%.1f, %.1f, %.1f\n", n2, n1, n3);
 } else {
printf("%.1f, %.1f, %.1f\n", n2, n3, n1);
 }
} 
else {
if (n1 < n2) {
printf("%.1f, %.1f, %.1f\n", n3, n1, n2);
 } else {
printf("%.1f, %.1f, %.1f\n", n3, n2, n1);
 }
}
system("pause");
}
