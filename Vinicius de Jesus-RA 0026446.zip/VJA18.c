#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-18 - Login simples ");
printf("\n************************************************************************************************************************");
int usuario_digitado,senha_digitada;
int usuario_certo = 1234, senha_certa = 2222;
printf("Qual o usuario?");
scanf("%d", &usuario_digitado);
printf("qual a senha?");
scanf("%d", &senha_digitada);
if(usuario_digitado==usuario_certo && senha_digitada==senha_certa){
	printf("Acesso permitido! Bem-vindo a Biblioteca.\n");
}else{
printf("Acesso negado! Usuario ou senha incorretos");
}
system("pause");
}
