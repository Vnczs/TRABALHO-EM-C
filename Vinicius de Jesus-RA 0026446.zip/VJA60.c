#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-60 - O Validador de Dias Uteis ");
printf("\n************************************************************************************************************************");
int dia;

    printf("--- CONTROLE DE ACESSO - CATRACA ---\n");
    printf("Digite o numero do dia da semana (1-Domingo ate 7-Sabado): ");
    scanf("%d", &dia);
    printf("\n[Status da Catraca]: ");
    switch (dia) {
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            printf("Dia Util. Acesso liberado para o trabalho.\n");
            break;
        case 1:
        case 7:
            printf("Fim de Semana. Predio fechado.\n");
            break;
        default:
            printf("Numero de dia invalido.\n");
            break;
    }
system("pause");
}
