#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-42 - Quantidade de n�meros �mpares digitados");
printf("\n************************************************************************************************************************");
int numero;
    int contador_impares = 0;
    int i = 1;                

    printf("--- Analisador de Numeros Impares (com while) ---\n\n");

  
    while (i <= 10) {
        printf("Digite o %d� numero: ", i);
        scanf("%d", &numero);

        
        if (numero % 2 != 0) {
            contador_impares++; 
        }

        i++; 
    }

    printf("\n--- Resultado ---\n");
    printf("Quantidade de numeros impares digitados: %d\n", contador_impares);


system("pause");

}
