#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-49 - Pedir senha at� acertar ");
printf("\n************************************************************************************************************************");
int senha;

    
    do {
        printf("Digite a senha de acesso: ");
        scanf("%d", &senha);

        
        if (senha != 1111) {
            printf("Senha incorreta! Tente novamente.\n\n");
        }

    } while (senha != 1111); 

    printf("Acesso liberado!\n");



system("pause");
}
