#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-17 - O Sensor do Parque Tematico ");
printf("\n************************************************************************************************************************");
float altura;
printf("Qual a altura da pessoa(em cm)?");
scanf("%f", &altura);
if(altura >=140){
printf("luz verde! liberado!");
}else{
printf("luz vermelha! Barrado!");
system("pause");
}


}
