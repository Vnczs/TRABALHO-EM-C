#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-20 - Ano bissexto");
printf("\n************************************************************************************************************************");
setlocale(LC_ALL, "Portuguese");
int ano;
printf("Verificador de Ano Bissexto\n");
printf("Digite o ano que deseja verificar: ");
scanf("%d", &ano);
if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)){
printf("O ano %d e BISSEXTO (possui 366 dias).\n", ano);
} else {
printf("O ano %d N�O  bissexto (possui 365 dias).\n", ano);
}
system("pause");

}
