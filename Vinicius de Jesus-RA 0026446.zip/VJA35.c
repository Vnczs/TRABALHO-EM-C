#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-35 - Numeros de Fibonacci (n termos)");
printf("\n************************************************************************************************************************");
int n, i;
int termo1 = 0;
int termo2 = 1;
int proximo;
printf("Quantos termos da sequencia de Fibonacci voce quer ver? ");
scanf("%d", &n);
printf("Os primeiros %d termos sao:\n", n);
if (n >= 1) {
printf("%d ", termo1); 
}
if (n >= 2) {
 printf("%d ", termo2); 
}
for (i = 3; i <= n; i++) {
proximo = termo1 + termo2; 
printf("%d ", proximo);  
termo1 = termo2; 
termo2 = proximo; 
}
printf("\n\n");
system("pause");
   
}










