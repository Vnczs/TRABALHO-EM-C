#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-24 - Pode votar");
printf("\n************************************************************************************************************************");
int idade;
printf("Digite sua idade:");
scanf("%d", &idade);
if(idade>=18){
printf("Pode votar!\n");
}else{
printf("Nao pode votar!\n");
}
system("pause");



}
