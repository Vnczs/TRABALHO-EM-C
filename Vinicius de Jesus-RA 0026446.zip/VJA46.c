#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-46 - Contar de 1 a 10");
printf("\n************************************************************************************************************************");
int i = 1; 
    do {
        printf("%d\n", i); 
        i++;              
        
    } while (i <= 10); 








system("pause");

}

