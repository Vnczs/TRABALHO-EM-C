#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-22 - numero par ou impar");
printf("\n************************************************************************************************************************");
int numero;
	printf("Digite um numero:");
	scanf("%d", &numero);
	if (numero % 2 == 0){
		printf("O nuemero %d e PAR.\n", numero);
	}
	else{
		printf("O numero %d e IMPAR.\n", numero);
	}
	system("pause");
}

