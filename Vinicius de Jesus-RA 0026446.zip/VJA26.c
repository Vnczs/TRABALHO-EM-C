#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-26 -  Contar de 1 a 10");
printf("\n************************************************************************************************************************");
int i;
printf("Chamada dos Alunos\n");
for (i=1; i<=10;i++){
printf("aluno numero %d\n", i);
}

system("pause");




}
