#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-32 -  Quadrado dos numeros de 1 a 10.");
printf("\n************************************************************************************************************************");
int i;
int resultado;
for(i=1; i<=10; i++){
resultado = i * i;
printf("%d Elevado ao quadrado e:%d\n", i, resultado);
}



system("pause");





}
