#include<stdio.h>
#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-23 - Maior de dois numeros");
printf("\n************************************************************************************************************************");
float n1, n2;
printf("Digite o primeiro numero:");
scanf("%f", &n1);
printf("Digite o segundo numero:");
scanf("%f", &n2);
if(n1>n2){
printf("O primeiro numero %.2f e maior!\n", n1);
}
else if (n2>n1){
printf("O segundo numero %.2f e  maior!\n", n2);
}
else{
printf("Os numeros sao iguais!\n");
}
system("pause");
}

