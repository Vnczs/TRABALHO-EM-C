#include<stdlib.h>
#include<locale.h>
#include<stdio.h>
int main(){
printf("\n************************************************************************************************************************");
printf("\n* Aluno: Vinicius de jesus alves de andrade - RA: 0026446");
printf("\n* Programa VJA-44 - Contar d�gitos de um n�mero");
printf("\n************************************************************************************************************************");
int numero, numero_reserva;
    int contador_digitos = 0;

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &numero);
    numero_reserva = numero;
    if (numero == 0) {
        contador_digitos = 1;
    } else {
        while (numero > 0) {
            contador_digitos++; 
            numero = numero / 10; 
        }
    }

    printf("O numero %d possui %d digito(s).\n", numero_reserva, contador_digitos);






system("pause");


}
